﻿namespace LibGit2Sharp.Tests.TestHelpers
{
    public interface IPostTestDirectoryRemover
    {
        void Register(string directoryPath);
    }
}

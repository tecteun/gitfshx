namespace LibGit2Sharp.Core
{
	internal static class NativeDllName
	{
		public const string Name = "git2-e0902fb";
	}
}

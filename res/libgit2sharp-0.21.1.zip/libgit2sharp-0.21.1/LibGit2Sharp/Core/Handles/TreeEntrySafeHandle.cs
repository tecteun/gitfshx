﻿namespace LibGit2Sharp.Core.Handles
{
    internal class TreeEntrySafeHandle : NotOwnedSafeHandleBase
    {
    }
}

﻿namespace LibGit2Sharp.Core.Handles
{
    internal class GitRefSpecHandle : NotOwnedSafeHandleBase
    {
    }
}

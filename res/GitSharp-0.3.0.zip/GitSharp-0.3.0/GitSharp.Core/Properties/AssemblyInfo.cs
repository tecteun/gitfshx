﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("GitSharp.Core")]
[assembly: AssemblyDescription("")]

[assembly: InternalsVisibleTo("GitSharp")]
[assembly: InternalsVisibleTo("GitSharp.Tests")]

CLI (Command Line Interface) is a not so close port of jgit's pgm-package and 
should be equivalent to the original git command line, however, it is not yet complete.